package Prog01_aOrderedList;

/**
 * The Prog01_aOrderedList class is the main class for this project. This class prompts the user for the input
 * filename, reads from the input file, processes add and delete operations using the aOrderedList class
 * 
 * CSC 1351 Programming Project No 1
 * Section 2
 * 
 * @author Kayla Theriot
 * @since 10/23/2023
 */

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Prog01_aOrderedList {
	
	/**
	 * the main method of the program creates an instance of the aOrderedList class, uses the GetInputFile
	 * method to retrieve an input file and read from it in order to manipulate the list of cars, executes "A"
	 * and "D" commands to add or delete 
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */
	
	public static void main(String[] args) throws FileNotFoundException {
		aOrderedList orderedList = new aOrderedList(); //creates an ordered list to store Car objects
		Scanner inputScanner = GetInputFile("Enter input filename: "); //get input file from user
		
		while (inputScanner.hasNextLine()) {
			String line = inputScanner.nextLine();
			String[] data = line.split(",");
			
			if (data.length >= 2) {
				String operation = data[0];
				
				//add a Car object to list
				if (operation.equals("A") && data.length == 4) {
					Car car = new Car(data[1], Integer.parseInt(data[2]), Integer.parseInt(data[3]));
					orderedList.add(car);
				} 
				
				//delete a Car object from the list
				else if (operation.equals("D") && data.length >= 2) {
					String makeToDelete = data[1];
					int yearToDelete = Integer.parseInt(data[2]);
					for(int i = 0; i < orderedList.size(); i++) {
						Car car = orderedList.get(i);
						if (car.getMake().equals(makeToDelete) && car.getYear() == yearToDelete) {
							orderedList.remove(i);
							break;
						}
					}
				}
			}
		}
		inputScanner.close();
		
		PrintWriter outputWriter = GetOutputFile("Enter output filename: "); //get output file from user
		outputWriter.println("Number of cars: " + orderedList.size() + "\n"); //writes the number of cars in the list
		
		//write car information to output file
		for (int i = 0; i < orderedList.size(); i++) {
			Car car = orderedList.get(i);
			
			outputWriter.println("Make: \t" + rightAlign(car.getMake(), 10));
			outputWriter.println("Year: \t" + rightAlign(String.valueOf(car.getYear()), 10));
			outputWriter.println("Price: \t" + rightAlign("$" + String.valueOf(car.getPrice()), 10) + "\n");
		}
		outputWriter.close();
	}
	
	/**
	 * right align a string
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */
	
	private static String rightAlign(String input, int width) {
		return String.format("%" + width + "s", input);
	}
	
	/**
	 * get the input file from the user
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */
	
	public static Scanner GetInputFile(String userPrompt) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in);
		String fileName;
		File file;
		
		do {
			System.out.print(userPrompt);
			fileName = sc.nextLine();
			file = new File(fileName);
			
			if (!file.exists()) {
				System.out.println("File does not exist. Would you like to continue? (Y/N)");
				String response = sc.nextLine();
				if (!response.equalsIgnoreCase("Y")) {
					sc.close();
					throw new FileNotFoundException("Program execution canceled.");
				}
			}
		}
		while (!file.exists());
		
		try {
			return new Scanner(file);
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
			sc.close();
			throw new RuntimeException("Error opening file.");
		}
	}
	
	/**
	 * get the output file from the user
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */
	
	public static PrintWriter GetOutputFile(String userPrompt) {
		Scanner sc = new Scanner(System.in);
		String fileName;
		File file;
		
		do {
			System.out.print(userPrompt);
			fileName = sc.nextLine();
			file = new File(fileName);
			
			if (file.exists()) {
				System.out.println("File already exists. Would you like to overwrite? (Y/N)");
				String response = sc.nextLine();
				if (!response.equalsIgnoreCase("Y")) {
					sc.close();
					throw new RuntimeException("File already exists.");
				}
			}
		}
		while (file.exists());
		try {
			return new PrintWriter(file);
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
			sc.close();
			throw new RuntimeException("Error creating output file.");
		}
	}
}