package Prog01_aOrderedList;

/**
 * The Car class represents an object that has attributes for make, year, and price. It
 * implements the Comparable interface so that a comparison method can be used based on the
 * attributes previously mentioned. This class contains methods to access and modify the
 * attributes.
 * 
 * CSC 1351 Programming Project No 1
 * Section 2
 * 
 * @author Kayla Theriot
 * @since 10/23/2023
 */

public class Car implements Comparable<Car> {
	private String make; //the make of the car
	private int year; //the year the car was made
	private int price; //the price of the car
	
	/**
	 * constructor to create a new Car object
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */
	
	public Car(String make, int year, int price) {
		this.make = make;
		this.year = year;
		this.price = price;
	}
	
	/**
	 * get the make of the car
	 * return the make of the car
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */
	
	public String getMake() {
		return make;
	}

	/**
	 * get the year of the car
	 * return the year of the car
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */
	
	public int getYear() {
		return year;
	}

	/**
	 * get the price of the car
	 * return the price of the car
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */
	
	public int getPrice() {
		return price;
	}
	
	/**
	 * compare this car with another car based on make and year
	 * negative value if this car is smaller, positive if it is larger, zero if they are equal
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */

	public int compareTo(Car other) {
		if (!make.equals(other.make)) {
			return make.compareTo(other.make);
		}
		else if (year != other.year) {
			return Integer.compare(year, other.year);
		}
		else {
			return Integer.compare(price, other.price);
		}
	}

	/**
	 * get a string representation of the Car object
	 * return a string that contains the make, year, and price of the car
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */
	public String toString() {
		return "Make: " + make + ", Year: " + year + ", Price: " + price;
	}
}















