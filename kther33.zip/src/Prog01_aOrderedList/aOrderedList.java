package Prog01_aOrderedList;

/**
 * The aOrderedList class is an ordered list that can hold any comparable objects, cars
 * in this instance. This class contains methods to add objects to the list in a specific
 * order, get objects by index, get the list's size, check if the list is empty, delete
 * objects that fit specified criteria, and manage an iterator.
 * 
 * CSC 1351 Programming Project No 1
 * Section 2
 * 
 * @author Kayla Theriot
 * @since 10/23/2023
 */

import java.util.Arrays;

public class aOrderedList {
	final int SIZEINCREMENTS = 20; //the size of the increment for increasing the list
	private Car[] oList; //an array of "Car" objects that stores the elements in the list
	private int listSize; //the current size of the list
	private int numObjects; //the number of objects in the list
	private int curr; //current index for iteration
	
	/**
	 * the "aOrderedList" constructor sets numObjects to 0, sets listSize to the value of SIZEINCREMENTS,
	 * and instantiates the array oList to an array the same size as SIZEINCREMENTS
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */

	public aOrderedList() {
		numObjects = 0;
		listSize = SIZEINCREMENTS;
		oList = new Car[listSize];
	}
	
	/**
	 * adds a new Car object to the list while keeping the sorted order specified in compareTo
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */

	public void add(Car newObject) {
		if (numObjects == listSize) {
			listSize += SIZEINCREMENTS;
			oList = Arrays.copyOf(oList, listSize + SIZEINCREMENTS);
		}

		int insertIndex = numObjects; 
		
		//finds the correct index to insert the newObject
		for (int i = 0; i < numObjects; i++) {
			if (newObject.compareTo(oList[i]) < 0) {
				insertIndex = i;
				break;
			}
		}
		
		//shift elements to make space for the newObject
		for (int i = numObjects; i > insertIndex; i--) {
			oList[i] = oList[i - 1];
		}
		oList[insertIndex] = newObject;
		numObjects++;
	}
	
	/**
	 * get the number of Car objects in the list
	 * returns the number of Car objects in the list
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */

	public int size() {
		return numObjects;
	}
	
	/**
	 * get the Car object at a specific index
	 * return the Car object at the index or null if index is out of bounds
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */

	public Car get(int index) {
		if (index >= 0 && index < numObjects) {
			return oList[index];
		}
		return null;
	}
	
	/**
	 * check if the list is empty
	 * return true if empty, otherwise false
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */

	public boolean isEmpty() {
		return numObjects == 0;
	}
	
	/**
	 * remove the Car object at a specific index in the list
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */

	public void remove(int index) {
		if (index >= 0 && index < numObjects) {
			for (int i = index; i < numObjects - 1; i++) {
				oList[i] = oList[i + 1];
			}
			numObjects--;
		}
	}
	
	/**
	 * reset the iterator index back to the beginning of the list
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */

	public void reset() {
		curr = 0;
	}
	
	/**
	 * get the next Car object in the list during iteration
	 * return the next Car object in the list or null if there are no more
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */
	
	public Car next() {
		if (hasNext()) {
			return oList[curr++];
		}
		return null;
	}
	
	/**
	 * check if there are more objects to iterate through in the list
	 * return true if there are more, otehrwise false
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */

	public boolean hasNext() {
		return curr < numObjects;
	}
	
	/**
	 * remove the last retrieved object during iteration
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */

	public void remove() {
		if (curr > 0) {
			remove(curr - 1);
			curr--;
		}
	}
	
	/**
	 * delete a specific "Car" object from the list based on attributes specified
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */

	public void delete(Car objectToDelete) {
		int index = -1;
		
		//find the index of the object to be deleted
		for (int i = 0; i < numObjects; i++) {
			if (oList[i].compareTo(objectToDelete) == 0) {
				index = i;
				break;
				}
			}
		if (index >= 0) {
			remove(index);
			}
		}
	
	/**
	 * convert the ordered list to a string by iterating through its elements
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 2
	 * 
	 * @author Kayla Theriot
	 * @since 10/23/2023
	 */
	
	public String toString() {
		StringBuilder result = new StringBuilder("[");
		for (int i = 0; i < numObjects; i++) {
			result.append(oList[i].toString());
			if (i < numObjects - 1) {
				result.append("; ");
				}
			}
		result.append("]");
		return result.toString();
		}
	}
